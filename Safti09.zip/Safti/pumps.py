"""
Pump control module for SAFTI.
"""
import time
import threading

PUMP_PINS = {
    "Orange":       17,
    "Apple":        27,
    "Multivitamin": 22,
    "Water":        23,
    "OlsiItalian":  24,
}

VOLUME_DURATIONS = {
    0.2: 6.0,
    0.3: 9.0,
    0.5: 15.0,
}

# ── RELAY POLARITY ──────────────────────────────────────────────────────────
# Most cheap relay boards (blue/red) are ACTIVE-LOW:
#   GPIO LOW  → relay coil energised → pump ON
#   GPIO HIGH → relay coil released  → pump OFF
# If your relays turn ON when GPIO is HIGH, set this to True.
RELAY_ACTIVE_HIGH = False

try:
    import RPi.GPIO as GPIO
    _MOCK = False
except (ImportError, RuntimeError):
    print("[pumps] RPi.GPIO not available – running in mock mode")
    _MOCK = True


class _MockGPIO:
    BCM  = "BCM"
    OUT  = "OUT"
    HIGH = True
    LOW  = False

    def setmode(self, mode):      print(f"[mock GPIO] setmode({mode})")
    def setup(self, pin, mode):   print(f"[mock GPIO] setup(pin={pin}, mode={mode})")
    def output(self, pin, state): print(f"[mock GPIO] output(pin={pin}, state={'HIGH' if state else 'LOW'})")
    def cleanup(self):            print("[mock GPIO] cleanup()")


if _MOCK:
    GPIO = _MockGPIO()


def _on():
    """GPIO state that turns a pump ON (respects relay polarity)."""
    return GPIO.HIGH if RELAY_ACTIVE_HIGH else GPIO.LOW


def _off():
    """GPIO state that turns a pump OFF (respects relay polarity)."""
    return GPIO.LOW if RELAY_ACTIVE_HIGH else GPIO.HIGH


def setup():
    """Initialise all pump pins as outputs in the OFF state."""
    GPIO.setmode(GPIO.BCM)
    for pin in PUMP_PINS.values():
        GPIO.setup(pin, GPIO.OUT)
        GPIO.output(pin, _off())   # safe start: all pumps off


def cleanup():
    """Turn off all pumps and release GPIO resources."""
    stop_all()
    GPIO.cleanup()


def dispense(drink: str, volume_l: float, on_finish=None):
    """
    Activate the pump for *drink* for the calibrated duration.
    Runs in a background thread; calls on_finish() when done.
    """
    pin      = PUMP_PINS[drink]
    duration = VOLUME_DURATIONS[volume_l]

    def _run():
        GPIO.output(pin, _on())
        time.sleep(duration)
        GPIO.output(pin, _off())
        if on_finish:
            on_finish()

    threading.Thread(target=_run, daemon=True).start()


def start_manual(drink: str):
    """Turn on a pump indefinitely (maintenance mode only)."""
    GPIO.output(PUMP_PINS[drink], _on())


def stop(drink: str):
    """Immediately stop a specific pump."""
    GPIO.output(PUMP_PINS[drink], _off())


def stop_all():
    """Immediately stop all pumps."""
    for pin in PUMP_PINS.values():
        GPIO.output(pin, _off())
