"""
SAFTI – Smart Beverage Dispenser
Touchscreen UI – landscape layout.
"""

import os
import tkinter as tk
from PIL import Image, ImageTk
import pumps

_BASE = os.path.dirname(os.path.abspath(__file__))

# ── Palette ───────────────────────────────────────────────────────────────────
BG       = "#0E0E0E"
SURFACE  = "#1A1A1A"
SURF2    = "#242424"
ACCENT   = "#E8321F"
ACCENT_H = "#C2280F"
TEXT     = "#F2F2F2"
TEXT_DIM = "#6E6E6E"
BORDER   = "#2C2C2C"
GREEN    = "#2ECC71"
GREEN_H  = "#27AE60"
RED_BTN  = "#FF3B30"
RED_H    = "#CC2A22"

# ── Typography ────────────────────────────────────────────────────────────────
F_H1    = ("Helvetica", 22, "bold")
F_H2    = ("Helvetica", 17, "bold")
F_BODY  = ("Helvetica", 14)
F_BTN   = ("Helvetica", 13, "bold")
F_SMALL = ("Helvetica", 11)

DRINKS = ["Orange", "Apple", "Multivitamin", "Water"]

DRINK_META = {
    "Orange":       {"asset": "oranges.png",     "color": "#FF6B35", "pump": "Orange"},
    "Apple":        {"asset": "apple.png",        "color": "#4CD964", "pump": "Apple"},
    "Multivitamin": {"asset": "multivitamin.png", "color": "#AF52DE", "pump": "Multivitamin"},
    "Water":        {"asset": "wasser.png",        "color": "#2196F3", "pump": "Water"},
}

VOLUMES = [
    (0.2, "200 ml", "Klein"),
    (0.3, "300 ml", "Mittel"),
    (0.5, "500 ml", "Groß"),
]

ALL_PUMPS = list(pumps.PUMP_PINS.keys())


def _load_img(path, size):
    try:
        img = Image.open(os.path.join(_BASE, path)).convert("RGBA")
        img = img.resize(size, Image.LANCZOS)
        return ImageTk.PhotoImage(img)
    except Exception:
        return None


class SaftiApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SAFTI")
        self.configure(bg=BG)
        self.attributes("-fullscreen", True)
        self.bind("<Escape>", lambda e: self.destroy())

        pumps.setup()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self._logo = _load_img("assets/saftihorizontal.png", (188, 52))
        self._drink_imgs = {
            name: _load_img(f"assets/{meta['asset']}", (76, 76))
            for name, meta in DRINK_META.items()
        }
        self._pump_indicators: dict = {}
        self._show_main()

    # ── Shared helpers ────────────────────────────────────────────────────────

    def _clear(self):
        for w in self.winfo_children():
            w.destroy()

    def _topbar(self, back_cmd=None, show_gear=False, center_text=None):
        bar = tk.Frame(self, bg=SURFACE, height=56)
        bar.pack(fill="x")
        bar.pack_propagate(False)
        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")

        if back_cmd:
            tk.Button(
                bar, text="← Zurück",
                font=F_SMALL, bg=SURFACE, fg=TEXT_DIM,
                activebackground=SURF2, activeforeground=TEXT,
                relief="flat", bd=0, cursor="hand2", padx=16,
                command=back_cmd,
            ).pack(side="left", fill="y")

        if show_gear:
            tk.Button(
                bar, text="⚙",
                font=("Helvetica", 19), bg=SURFACE, fg=TEXT_DIM,
                activebackground=SURF2, activeforeground=TEXT,
                relief="flat", bd=0, cursor="hand2", padx=18,
                command=self._show_maintenance,
            ).pack(side="right", fill="y")

        if center_text:
            tk.Label(bar, text=center_text, font=F_H2,
                     bg=SURFACE, fg=TEXT).place(relx=0.5, rely=0.5, anchor="center")
        elif self._logo:
            tk.Label(bar, image=self._logo, bg=SURFACE).place(
                relx=0.5, rely=0.5, anchor="center")
        else:
            tk.Label(bar, text="SAFTI", font=F_H1,
                     bg=SURFACE, fg=ACCENT).place(
                relx=0.5, rely=0.5, anchor="center")

    # ── Main screen ───────────────────────────────────────────────────────────

    def _show_main(self):
        self._clear()
        self._topbar(show_gear=True)

        grid = tk.Frame(self, bg=BG)
        grid.pack(expand=True, fill="both", padx=12, pady=10)
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)
        grid.rowconfigure(0, weight=1)
        grid.rowconfigure(1, weight=1)

        for i, drink in enumerate(DRINKS):
            r, c = divmod(i, 2)
            self._drink_card(grid, drink, r, c)

    def _drink_card(self, parent, drink: str, row: int, col: int):
        meta = DRINK_META[drink]
        img  = self._drink_imgs.get(drink)

        outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
        outer.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")

        card = tk.Frame(outer, bg=SURFACE)
        card.pack(fill="both", expand=True)

        tk.Frame(card, bg=meta["color"], height=4).pack(fill="x")

        # Landscape card body: image | divider | name + button
        body = tk.Frame(card, bg=SURFACE)
        body.pack(fill="both", expand=True, padx=14, pady=10)

        # Fixed-width image column
        img_col = tk.Frame(body, bg=SURFACE, width=88)
        img_col.pack(side="left", fill="y")
        img_col.pack_propagate(False)
        if img:
            tk.Label(img_col, image=img, bg=SURFACE).place(
                relx=0.5, rely=0.5, anchor="center")
        else:
            tk.Label(img_col, text="🥤", font=("Helvetica", 32),
                     bg=SURFACE).place(relx=0.5, rely=0.5, anchor="center")

        tk.Frame(body, bg=BORDER, width=1).pack(side="left", fill="y", padx=(12, 16))

        # Text + button column
        info = tk.Frame(body, bg=SURFACE)
        info.pack(side="left", fill="both", expand=True)

        tk.Label(info, text=drink,
                 font=("Helvetica", 16, "bold"),
                 bg=SURFACE, fg=TEXT, anchor="w").pack(anchor="w")
        tk.Label(info, text="Getränk auswählen",
                 font=F_SMALL, bg=SURFACE, fg=TEXT_DIM, anchor="w").pack(anchor="w", pady=(2, 0))

        tk.Frame(info, bg=SURFACE).pack(expand=True, fill="y")

        tk.Button(
            info, text="Zapfen →",
            font=F_BTN, bg=ACCENT, fg=TEXT,
            activebackground=ACCENT_H, activeforeground=TEXT,
            relief="flat", bd=0, cursor="hand2", padx=16, pady=8,
            command=lambda d=drink: self._show_size(d),
        ).pack(anchor="w")

    # ── Size screen ───────────────────────────────────────────────────────────

    def _show_size(self, drink: str):
        self._clear()
        meta = DRINK_META[drink]
        self._topbar(back_cmd=self._show_main)

        content = tk.Frame(self, bg=BG)
        content.pack(expand=True, fill="both", padx=14, pady=10)
        content.columnconfigure(0, weight=1, minsize=190)
        content.columnconfigure(1, weight=3)
        content.rowconfigure(0, weight=1)

        # Left: drink preview
        left = tk.Frame(content, bg=SURFACE)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        tk.Frame(left, bg=meta["color"], height=4).pack(fill="x")

        lbody = tk.Frame(left, bg=SURFACE, padx=18, pady=16)
        lbody.pack(fill="both", expand=True)

        img = self._drink_imgs.get(drink)
        if img:
            tk.Label(lbody, image=img, bg=SURFACE).pack(pady=(4, 10))
        tk.Label(lbody, text=drink, font=F_H1,
                 bg=SURFACE, fg=TEXT).pack()
        tk.Label(lbody, text="Wähle deine Menge",
                 font=F_SMALL, bg=SURFACE, fg=TEXT_DIM).pack(pady=(4, 0))

        # Right: size rows (3 rows, equal height)
        right = tk.Frame(content, bg=BG)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        for i in range(3):
            right.rowconfigure(i, weight=1)

        for idx, (vol, label, desc) in enumerate(VOLUMES):
            self._size_row(right, drink, vol, label, desc, meta["color"], idx)

    def _size_row(self, parent, drink: str, vol: float,
                  label: str, desc: str, color: str, idx: int):
        outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
        outer.grid(row=idx, column=0, sticky="nsew", pady=4)

        frame = tk.Frame(outer, bg=SURFACE)
        frame.pack(fill="both", expand=True)

        tk.Frame(frame, bg=color, width=5).pack(side="left", fill="y")

        inner = tk.Frame(frame, bg=SURFACE, padx=18)
        inner.pack(side="left", fill="both", expand=True)

        tk.Label(inner, text=label,
                 font=("Helvetica", 18, "bold"),
                 bg=SURFACE, fg=TEXT).pack(side="left")
        tk.Label(inner, text=desc,
                 font=F_BODY, bg=SURFACE, fg=TEXT_DIM).pack(side="left", padx=14)

        tk.Button(
            inner, text="Wählen",
            font=F_BTN, bg=ACCENT, fg=TEXT,
            activebackground=ACCENT_H, activeforeground=TEXT,
            relief="flat", bd=0, cursor="hand2", padx=20, pady=10,
            command=lambda v=vol: self._start_dispense(drink, v),
        ).pack(side="right", pady=10)

    # ── Dispensing ────────────────────────────────────────────────────────────

    def _start_dispense(self, drink: str, volume: float):
        self._clear()
        meta = DRINK_META[drink]
        ml   = int(volume * 1000)
        dur  = pumps.VOLUME_DURATIONS[volume]

        self._topbar()

        content = tk.Frame(self, bg=BG)
        content.pack(expand=True, fill="both", padx=40, pady=20)

        # Left: drink image + name
        left = tk.Frame(content, bg=BG, width=170)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        img = self._drink_imgs.get(drink)
        if img:
            tk.Label(left, image=img, bg=BG).place(relx=0.5, rely=0.38, anchor="center")
        else:
            tk.Label(left, text="🥤", font=("Helvetica", 52),
                     bg=BG).place(relx=0.5, rely=0.38, anchor="center")
        tk.Label(left, text=drink, font=F_H2,
                 bg=BG, fg=TEXT).place(relx=0.5, rely=0.70, anchor="center")

        tk.Frame(content, bg=BORDER, width=1).pack(side="left", fill="y", padx=32)

        # Right: progress info
        right = tk.Frame(content, bg=BG)
        right.pack(side="left", expand=True, fill="both")

        tk.Label(right, text=f"Zapfe {ml} ml …",
                 font=F_BODY, bg=BG, fg=TEXT_DIM).pack(anchor="w", pady=(20, 14))

        # Canvas-based progress bar
        bar_cv = tk.Canvas(right, bg=SURF2, height=14,
                           highlightthickness=0, bd=0)
        bar_cv.pack(fill="x")
        bar_r = bar_cv.create_rectangle(0, 0, 0, 14, fill=meta["color"], outline="")

        pct_var = tk.StringVar(value="0 %")
        tk.Label(right, textvariable=pct_var,
                 font=F_SMALL, bg=BG, fg=TEXT_DIM).pack(anchor="w", pady=6)

        def _tick(elapsed: float):
            frac = min(elapsed / dur, 1.0)
            w = bar_cv.winfo_width() or 400
            bar_cv.coords(bar_r, 0, 0, w * frac, 14)
            pct_var.set(f"{int(frac * 100)} %")
            if elapsed < dur:
                self.after(80, _tick, elapsed + 0.08)

        def _done():
            self.after(0, self._show_done, drink, ml)

        pumps.dispense(meta["pump"], volume, on_finish=_done)
        self.after(50, _tick, 0.0)

    # ── Done screen ───────────────────────────────────────────────────────────

    def _show_done(self, drink: str, ml: int):
        self._clear()
        meta = DRINK_META[drink]

        self._topbar()

        content = tk.Frame(self, bg=BG)
        content.pack(expand=True)

        tk.Label(content, text="✓",
                 font=("Helvetica", 90, "bold"),
                 bg=BG, fg=GREEN).pack(side="left", padx=(0, 32))

        info = tk.Frame(content, bg=BG)
        info.pack(side="left")

        tk.Label(info, text="Fertig!", font=F_H1,
                 bg=BG, fg=TEXT).pack(anchor="w")

        detail = tk.Frame(info, bg=BG)
        detail.pack(anchor="w", pady=(6, 18))
        img = self._drink_imgs.get(drink)
        if img:
            tk.Label(detail, image=img, bg=BG).pack(side="left", padx=(0, 10))
        tk.Label(detail, text=f"{drink}  ·  {ml} ml",
                 font=F_H2, bg=BG, fg=TEXT_DIM).pack(side="left")

        tk.Button(
            info, text="Neues Getränk",
            font=F_BTN, bg=ACCENT, fg=TEXT,
            activebackground=ACCENT_H, activeforeground=TEXT,
            relief="flat", bd=0, cursor="hand2", padx=28, pady=12,
            command=self._show_main,
        ).pack(anchor="w")

    # ── Maintenance mode ──────────────────────────────────────────────────────

    def _show_maintenance(self):
        self._clear()
        self._topbar(back_cmd=self._show_main, center_text="⚙  Wartungsmodus")
        self._pump_indicators = {}

        content = tk.Frame(self, bg=BG)
        content.pack(expand=True, fill="both", padx=14, pady=10)
        content.columnconfigure(0, weight=1, minsize=190)
        content.columnconfigure(1, weight=3)
        content.rowconfigure(0, weight=1)

        # Left panel: info + stop-all
        left = tk.Frame(content, bg=SURFACE)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        tk.Frame(left, bg=ACCENT, height=4).pack(fill="x")

        lbody = tk.Frame(left, bg=SURFACE, padx=18, pady=18)
        lbody.pack(fill="both", expand=True)

        tk.Label(lbody, text="Pumpen\nsteuern",
                 font=F_H2, bg=SURFACE, fg=TEXT, justify="left").pack(anchor="w")
        tk.Frame(lbody, bg=BORDER, height=1).pack(fill="x", pady=12)
        tk.Label(lbody,
                 text="EIN  → Pumpe starten\nAUS  → Pumpe stoppen\n⏹    → Alle sofort aus",
                 font=F_SMALL, bg=SURFACE, fg=TEXT_DIM, justify="left").pack(anchor="w")

        tk.Frame(lbody, bg=SURFACE).pack(expand=True, fill="y")

        tk.Button(
            lbody, text="⏹  Alle stoppen",
            font=F_BTN, bg=RED_BTN, fg=TEXT,
            activebackground=RED_H, activeforeground=TEXT,
            relief="flat", bd=0, cursor="hand2", padx=14, pady=12,
            command=self._stop_all,
        ).pack(fill="x")

        # Right panel: pump rows
        right = tk.Frame(content, bg=BG)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        for i in range(len(ALL_PUMPS)):
            right.rowconfigure(i, weight=1)

        for i, pump_key in enumerate(ALL_PUMPS):
            self._pump_row(right, pump_key, i)

    def _pump_row(self, parent, pump_key: str, row: int):
        outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
        outer.grid(row=row, column=0, sticky="nsew", pady=4)

        frame = tk.Frame(outer, bg=SURFACE)
        frame.pack(fill="both", expand=True)

        dot = tk.Label(frame, text="●", font=("Helvetica", 12),
                       bg=SURFACE, fg=BORDER)
        dot.pack(side="left", padx=(12, 8))
        self._pump_indicators[pump_key] = dot

        tk.Label(frame, text=pump_key,
                 font=("Helvetica", 13, "bold"),
                 bg=SURFACE, fg=TEXT, anchor="w", width=13).pack(side="left")

        tk.Button(
            frame, text="AUS",
            font=F_SMALL, bg=SURF2, fg=TEXT_DIM,
            activebackground=BORDER, activeforeground=TEXT,
            relief="flat", bd=0, cursor="hand2", padx=14, pady=8,
            command=lambda k=pump_key: self._pump_off(k),
        ).pack(side="right", padx=(4, 12), pady=8)

        tk.Button(
            frame, text="EIN",
            font=F_SMALL, bg=GREEN, fg="#000000",
            activebackground=GREEN_H, activeforeground="#000000",
            relief="flat", bd=0, cursor="hand2", padx=14, pady=8,
            command=lambda k=pump_key: self._pump_on(k),
        ).pack(side="right", padx=4, pady=8)

    def _pump_on(self, key: str):
        pumps.start_manual(key)
        if key in self._pump_indicators:
            self._pump_indicators[key].configure(fg=GREEN)

    def _pump_off(self, key: str):
        pumps.stop(key)
        if key in self._pump_indicators:
            self._pump_indicators[key].configure(fg=BORDER)

    def _stop_all(self):
        pumps.stop_all()
        for dot in self._pump_indicators.values():
            dot.configure(fg=BORDER)

    # ── Cleanup ───────────────────────────────────────────────────────────────

    def _on_close(self):
        pumps.cleanup()
        self.destroy()


if __name__ == "__main__":
    app = SaftiApp()
    app.mainloop()
