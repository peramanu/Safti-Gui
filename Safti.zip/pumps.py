"""
Pump control module for SAFTI.
"""
import time
import threading

PUMP_PINS = {
    "Orange":       17,
    "Apple":        27,
    "Multivitamin": 22,
    "Water":        23,
}

VOLUME_DURATIONS = {
    0.2: 6.0,
    0.3: 9.0,
    0.5: 15.0,
}

try:
    import RPi.GPIO as GPIO
    _MOCK = False
except (ImportError, RuntimeError):
    print("[pumps] RPi.GPIO not available – running in mock mode")
    _MOCK = True


class _MockGPIO:
    BCM  = "BCM"
    OUT  = "OUT"
    HIGH = True
    LOW  = False

    def setmode(self, mode):      print(f"[mock GPIO] setmode({mode})")
    def setup(self, pin, mode):   print(f"[mock GPIO] setup(pin={pin}, mode={mode})")
    def output(self, pin, state): print(f"[mock GPIO] output(pin={pin}, state={'HIGH' if state else 'LOW'})")
    def cleanup(self):            print("[mock GPIO] cleanup()")


if _MOCK:
    GPIO = _MockGPIO()


def setup():
    GPIO.setmode(GPIO.BCM)
    for pin in PUMP_PINS.values():
        GPIO.setup(pin, GPIO.OUT)
        GPIO.output(pin, GPIO.LOW)


def cleanup():
    stop_all()
    GPIO.cleanup()


def dispense(drink: str, volume_l: float, on_finish=None):
    pin      = PUMP_PINS[drink]
    duration = VOLUME_DURATIONS[volume_l]

    def _run():
        GPIO.output(pin, GPIO.HIGH)
        time.sleep(duration)
        GPIO.output(pin, GPIO.LOW)
        if on_finish:
            on_finish()

    threading.Thread(target=_run, daemon=True).start()


def start_manual(drink: str):
    """Turn on a pump without a timer (maintenance mode)."""
    GPIO.output(PUMP_PINS[drink], GPIO.HIGH)


def stop(drink: str):
    """Immediately stop a specific pump."""
    GPIO.output(PUMP_PINS[drink], GPIO.LOW)


def stop_all():
    """Immediately stop all pumps."""
    for pin in PUMP_PINS.values():
        GPIO.output(pin, GPIO.LOW)
