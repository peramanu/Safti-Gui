import os
import customtkinter as ctk
from PIL import Image
import pumps

_BASE = os.path.dirname(os.path.abspath(__file__))

# ─── TRANSLATIONS ─────────────────────────────────────────────────────────────
LANG = {
    "DE": {
        "title":        "Getränke wählen",
        "size_title":   "Glasgröße wählen",
        "small":        "Klein",
        "medium":       "Mittel",
        "large":        "Groß",
        "dispense_btn": "Zapfen",
        "select_btn":   "Wählen",
        "back_btn":     "← Zurück",
        "ready":        "Bereit – Wähle ein Getränk",
        "dispensing":   "wird gezapft …",
        "tagline":      "Frisch gepresst.\nDirekt für dich.",
        "maintenance":  "Wartung",
        "enter_pin":    "Bitte PIN eingeben",
        "wrong_pin":    "Falscher PIN – erneut versuchen",
        "pump_on":      "EIN",
        "pump_off":     "AUS",
        "stop_all":     "Alle Pumpen stoppen",
        "exit_maint":   "Wartung beenden",
        "maint_title":  "Wartungsmodus",
        "maint_sub":    "Pumpen manuell steuern",
        "language":     "Sprache",
        "drinks": {
            "Orange":       "Orange",
            "Apfel":        "Apfel",
            "Wasser":       "Wasser",
            "Multivitamin": "Multivitamin",
            "OlsiItalian":  "Olsi Italian",
        },
    },
    "EN": {
        "title":        "Choose your drink",
        "size_title":   "Choose size",
        "small":        "Small",
        "medium":       "Medium",
        "large":        "Large",
        "dispense_btn": "Dispense",
        "select_btn":   "Select",
        "back_btn":     "← Back",
        "ready":        "Ready – Choose a drink",
        "dispensing":   "dispensing …",
        "tagline":      "Fresh pressed.\nJust for you.",
        "maintenance":  "Maintenance",
        "enter_pin":    "Please enter PIN",
        "wrong_pin":    "Wrong PIN – please try again",
        "pump_on":      "ON",
        "pump_off":     "OFF",
        "stop_all":     "Stop all pumps",
        "exit_maint":   "Exit maintenance",
        "maint_title":  "Maintenance Mode",
        "maint_sub":    "Manual pump control",
        "language":     "Language",
        "drinks": {
            "Orange":       "Orange",
            "Apfel":        "Apple",
            "Wasser":       "Water",
            "Multivitamin": "Multivitamin",
            "OlsiItalian":  "Olsi Italian",
        },
    },
}

DRINK_TO_PUMP = {
    "Orange":       "Orange",
    "Apfel":        "Apple",
    "Wasser":       "Water",
    "Multivitamin": "Multivitamin",
    "OlsiItalian":  "OlsiItalian",
}

# ─── DESIGN TOKENS ────────────────────────────────────────────────────────────
BG             = "#0A0A0F"
SIDEBAR_BG     = "#111118"
CARD           = "#18181F"
CARD_HOVER     = "#1E1E28"
ACCENT         = "#E8321F"
ACCENT_HOVER   = "#C2280E"
TEXT           = "#F2F2F7"
TEXT_SECONDARY = "#8E8E93"
BORDER         = "#2C2C2E"
SUCCESS        = "#30D158"
WARNING        = "#FF9F0A"
GREEN_HOVER    = "#25A045"

MAINTENANCE_PIN = "2009"
current_lang = "DE"


def t(key):
    return LANG[current_lang].get(key, key)


def drink_name(k):
    return LANG[current_lang]["drinks"].get(k, k)


# ─── APP SETUP ────────────────────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

root = ctk.CTk()
root.geometry("1060x660")
root.minsize(900, 600)
root.title("Safti")

pumps.setup()
root.protocol("WM_DELETE_WINDOW", lambda: (pumps.cleanup(), root.destroy()))


def load_img(path, size):
    return ctk.CTkImage(Image.open(os.path.join(_BASE, path)), size=size)


# ─── IMAGES ───────────────────────────────────────────────────────────────────
logo_img   = load_img("assets/saftihorizontal.png", (210, 58))
orange_img = load_img("assets/oranges.png",         (90, 90))
apple_img  = load_img("assets/apple.png",           (90, 90))
water_img  = load_img("assets/wasser.png",          (90, 90))
multi_img  = load_img("assets/multivitamin.png",    (90, 90))
try:
    olsi_img = load_img("assets/olsi.png", (90, 90))
except Exception:
    olsi_img = multi_img  # replace with assets/olsi.png when available

DRINK_DATA = [
    ("Orange",       orange_img),
    ("Apfel",        apple_img),
    ("Wasser",       water_img),
    ("Multivitamin", multi_img),
    ("OlsiItalian",  olsi_img),
]

# ─── ROOT LAYOUT ──────────────────────────────────────────────────────────────
sidebar = ctk.CTkFrame(root, fg_color=SIDEBAR_BG, width=230, corner_radius=0)
sidebar.pack(side="left", fill="y")
sidebar.pack_propagate(False)

main = ctk.CTkFrame(root, fg_color=BG, corner_radius=0)
main.pack(side="left", expand=True, fill="both")

# ─── SIDEBAR ──────────────────────────────────────────────────────────────────
ctk.CTkLabel(sidebar, image=logo_img, text="", fg_color=SIDEBAR_BG).pack(pady=(36, 0))
ctk.CTkFrame(sidebar, fg_color=BORDER, height=1).pack(fill="x", padx=20, pady=24)

tagline_label = ctk.CTkLabel(
    sidebar, text=t("tagline"),
    font=("Segoe UI", 12), text_color=TEXT_SECONDARY,
    fg_color=SIDEBAR_BG, justify="center",
)
tagline_label.pack(padx=20)

ctk.CTkFrame(sidebar, fg_color=BORDER, height=1).pack(fill="x", padx=20, pady=24)

lang_header = ctk.CTkLabel(
    sidebar, text=t("language"),
    font=("Segoe UI", 11), text_color=TEXT_SECONDARY,
    fg_color=SIDEBAR_BG,
)
lang_header.pack()

lang_row = ctk.CTkFrame(sidebar, fg_color="transparent")
lang_row.pack(pady=8)

btn_de = ctk.CTkButton(
    lang_row, text="DE", width=56, height=34,
    font=("Segoe UI", 12, "bold"),
    fg_color=ACCENT, hover_color=ACCENT_HOVER,
    text_color=TEXT, corner_radius=8,
    command=lambda: set_language("DE"),
)
btn_de.pack(side="left", padx=(0, 6))

btn_en = ctk.CTkButton(
    lang_row, text="EN", width=56, height=34,
    font=("Segoe UI", 12, "bold"),
    fg_color=CARD, hover_color=CARD_HOVER,
    text_color=TEXT, corner_radius=8,
    command=lambda: set_language("EN"),
)
btn_en.pack(side="left")

# Sidebar bottom: maintenance button + version
sidebar_bottom = ctk.CTkFrame(sidebar, fg_color="transparent")
sidebar_bottom.pack(side="bottom", pady=20, padx=16, fill="x")

maint_btn = ctk.CTkButton(
    sidebar_bottom,
    text="⚙  " + t("maintenance"),
    font=("Segoe UI", 11), height=34,
    fg_color=CARD, hover_color=CARD_HOVER,
    text_color=TEXT_SECONDARY, corner_radius=8,
    border_width=1, border_color=BORDER,
    command=lambda: show_pin_dialog(),
)
maint_btn.pack(fill="x", pady=(0, 8))

ctk.CTkLabel(
    sidebar_bottom, text="v1.0",
    font=("Segoe UI", 11), text_color=BORDER,
    fg_color="transparent",
).pack()

# ─── MAIN: HEADER ─────────────────────────────────────────────────────────────
header = ctk.CTkFrame(main, fg_color=BG, height=70)
header.pack(fill="x")
header.pack_propagate(False)

header_title = ctk.CTkLabel(
    header, text=t("title"),
    font=("Segoe UI", 24, "bold"),
    text_color=TEXT, fg_color=BG,
)
header_title.place(x=32, rely=0.5, anchor="w")

ctk.CTkFrame(main, fg_color=BORDER, height=1).pack(fill="x")

# ─── CONTENT FRAMES ───────────────────────────────────────────────────────────
grid_frame        = ctk.CTkFrame(main, fg_color=BG)
size_frame        = ctk.CTkFrame(main, fg_color=BG)
maintenance_frame = ctk.CTkFrame(main, fg_color=BG)

grid_frame.pack(expand=True)
grid_frame.columnconfigure((0, 1), weight=1, minsize=220)
grid_frame.rowconfigure((0, 1, 2), weight=1)

# ─── STATUS BAR ───────────────────────────────────────────────────────────────
ctk.CTkFrame(main, fg_color=BORDER, height=1).pack(fill="x", side="bottom")

status_bar = ctk.CTkFrame(main, fg_color=SIDEBAR_BG, height=46, corner_radius=0)
status_bar.pack(fill="x", side="bottom")
status_bar.pack_propagate(False)

status_dot = ctk.CTkLabel(
    status_bar, text="●",
    font=("Segoe UI", 11), text_color=SUCCESS,
    fg_color=SIDEBAR_BG,
)
status_dot.place(x=18, rely=0.5, anchor="w")

status = ctk.CTkLabel(
    status_bar, text=t("ready"),
    font=("Segoe UI", 12), text_color=TEXT_SECONDARY,
    fg_color=SIDEBAR_BG,
)
status.place(x=36, rely=0.5, anchor="w")

# ─── DRINK CARDS ──────────────────────────────────────────────────────────────
drink_card_refs = {}


def drink_card(parent, image, name, index, colspan=1):
    r, c = divmod(index, 2)
    card = ctk.CTkFrame(
        parent, fg_color=CARD, corner_radius=16,
        border_width=1, border_color=BORDER,
    )
    card.grid(row=r, column=c, columnspan=colspan, padx=20, pady=20, sticky="nsew")

    ctk.CTkFrame(card, fg_color=ACCENT, height=4, corner_radius=0).pack(fill="x")
    ctk.CTkLabel(card, image=image, text="", fg_color=CARD).pack(pady=(20, 8))

    lbl = ctk.CTkLabel(
        card, text=drink_name(name),
        font=("Segoe UI", 17, "bold"),
        text_color=TEXT, fg_color=CARD,
    )
    lbl.pack()

    ctk.CTkFrame(card, fg_color=BORDER, height=1).pack(fill="x", padx=20, pady=14)

    btn = ctk.CTkButton(
        card, text=t("dispense_btn"),
        font=("Segoe UI", 13, "bold"),
        fg_color=ACCENT, hover_color=ACCENT_HOVER,
        text_color="white", corner_radius=10,
        width=130, height=40,
        command=lambda n=name: choose_size(n),
    )
    btn.pack(pady=(0, 20))

    drink_card_refs[name] = {"label": lbl, "btn": btn}


for i, (nm, img) in enumerate(DRINK_DATA):
    # last card gets colspan=2 when there's an odd number of drinks
    span = 2 if (i == len(DRINK_DATA) - 1 and len(DRINK_DATA) % 2 == 1) else 1
    drink_card(grid_frame, img, nm, i, colspan=span)

# ─── NAVIGATION ───────────────────────────────────────────────────────────────

def show_main_view():
    size_frame.pack_forget()
    maintenance_frame.pack_forget()
    grid_frame.pack(expand=True)
    header_title.configure(text=t("title"))


def choose_size(drink):
    grid_frame.pack_forget()
    for w in size_frame.winfo_children():
        w.destroy()

    size_frame.pack(expand=True, fill="both", padx=60, pady=20)
    header_title.configure(text=f"{drink_name(drink)} – {t('size_title')}")

    SIZES = [
        ("0.2", t("small")),
        ("0.3", t("medium")),
        ("0.5", t("large")),
    ]

    def start(size_val):
        show_main_view()
        pump_key = DRINK_TO_PUMP.get(drink, drink)
        vol = float(size_val)
        status_dot.configure(text_color=WARNING)
        status.configure(text=f"{drink_name(drink)}  ·  {size_val} L  {t('dispensing')}")

        def on_done():
            status_dot.configure(text_color=SUCCESS)
            status.configure(text=t("ready"))

        pumps.dispense(pump_key, vol, on_finish=lambda: root.after(0, on_done))

    for size_val, size_nm in SIZES:
        row = ctk.CTkFrame(size_frame, fg_color=CARD, corner_radius=12, height=70)
        row.pack(fill="x", pady=8)
        row.pack_propagate(False)

        ctk.CTkFrame(row, fg_color=ACCENT, width=4, corner_radius=0).place(
            x=0, y=0, relheight=1
        )

        ctk.CTkLabel(
            row, text=f"{size_val} L",
            font=("Segoe UI", 18, "bold"),
            text_color=TEXT, fg_color=CARD,
        ).place(relx=0.12, rely=0.5, anchor="center")

        ctk.CTkLabel(
            row, text=size_nm,
            font=("Segoe UI", 13),
            text_color=TEXT_SECONDARY, fg_color=CARD,
        ).place(relx=0.35, rely=0.5, anchor="center")

        ctk.CTkButton(
            row, text=t("select_btn"),
            font=("Segoe UI", 13, "bold"),
            fg_color=ACCENT, hover_color=ACCENT_HOVER,
            text_color="white", corner_radius=8,
            width=110, height=40,
            command=lambda s=size_val: start(s),
        ).place(relx=0.82, rely=0.5, anchor="center")

    ctk.CTkButton(
        size_frame, text=t("back_btn"),
        font=("Segoe UI", 13),
        fg_color="transparent", hover_color=BORDER,
        text_color=TEXT_SECONDARY,
        border_color=BORDER, border_width=1,
        corner_radius=8, height=40,
        command=show_main_view,
    ).pack(pady=(20, 0), fill="x")

# ─── LANGUAGE SWITCH ──────────────────────────────────────────────────────────

def set_language(lang):
    global current_lang
    current_lang = lang

    btn_de.configure(fg_color=ACCENT if lang == "DE" else CARD)
    btn_en.configure(fg_color=ACCENT if lang == "EN" else CARD)

    tagline_label.configure(text=t("tagline"))
    lang_header.configure(text=t("language"))
    maint_btn.configure(text="⚙  " + t("maintenance"))
    header_title.configure(text=t("title"))
    status.configure(text=t("ready"))

    for name, refs in drink_card_refs.items():
        refs["label"].configure(text=drink_name(name))
        refs["btn"].configure(text=t("dispense_btn"))

# ─── PIN DIALOG ───────────────────────────────────────────────────────────────

def show_pin_dialog():
    dlg = ctk.CTkToplevel(root)
    dlg.title("")
    dlg.geometry("360x460")
    dlg.resizable(False, False)
    dlg.configure(fg_color=SIDEBAR_BG)
    dlg.transient(root)
    dlg.grab_set()
    dlg.focus_force()

    dlg.update_idletasks()
    x = root.winfo_x() + (root.winfo_width()  - 360) // 2
    y = root.winfo_y() + (root.winfo_height() - 460) // 2
    dlg.geometry(f"360x460+{x}+{y}")

    ctk.CTkLabel(
        dlg, text="⚙  " + t("maintenance"),
        font=("Segoe UI", 20, "bold"),
        text_color=TEXT, fg_color=SIDEBAR_BG,
    ).pack(pady=(30, 6))

    ctk.CTkLabel(
        dlg, text=t("enter_pin"),
        font=("Segoe UI", 13),
        text_color=TEXT_SECONDARY, fg_color=SIDEBAR_BG,
    ).pack(pady=(0, 16))

    # PIN display
    pin_box = ctk.CTkFrame(dlg, fg_color=CARD, corner_radius=10, height=54, width=200)
    pin_box.pack_propagate(False)
    pin_box.pack()

    pin_lbl = ctk.CTkLabel(
        pin_box, text="",
        font=("Segoe UI", 28, "bold"),
        text_color=TEXT, fg_color=CARD,
    )
    pin_lbl.place(relx=0.5, rely=0.5, anchor="center")

    error_lbl = ctk.CTkLabel(
        dlg, text="",
        font=("Segoe UI", 12),
        text_color=ACCENT, fg_color=SIDEBAR_BG,
    )
    error_lbl.pack(pady=6)

    current_pin = []

    def press(digit):
        if len(current_pin) < 4:
            current_pin.append(str(digit))
            pin_lbl.configure(text="●" * len(current_pin))
            error_lbl.configure(text="")

    def delete():
        if current_pin:
            current_pin.pop()
            pin_lbl.configure(text="●" * len(current_pin))

    def confirm():
        if "".join(current_pin) == MAINTENANCE_PIN:
            dlg.destroy()
            show_maintenance()
        else:
            error_lbl.configure(text=t("wrong_pin"))
            current_pin.clear()
            pin_lbl.configure(text="")

    def on_key(event):
        if event.char.isdigit():
            press(event.char)
        elif event.keysym == "BackSpace":
            delete()
        elif event.keysym in ("Return", "KP_Enter"):
            confirm()
        elif event.keysym == "Escape":
            dlg.destroy()

    dlg.bind("<Key>", on_key)

    numpad = ctk.CTkFrame(dlg, fg_color="transparent")
    numpad.pack(pady=6)

    LAYOUT = [
        ["1", "2", "3"],
        ["4", "5", "6"],
        ["7", "8", "9"],
        ["⌫", "0", "✓"],
    ]

    for r, row_keys in enumerate(LAYOUT):
        for c, key in enumerate(row_keys):
            if key == "⌫":
                cmd, bg, hv, tc = delete, CARD, CARD_HOVER, TEXT_SECONDARY
            elif key == "✓":
                cmd, bg, hv, tc = confirm, ACCENT, ACCENT_HOVER, TEXT
            else:
                cmd, bg, hv, tc = (lambda k=key: press(k)), CARD, CARD_HOVER, TEXT

            ctk.CTkButton(
                numpad, text=key,
                width=76, height=54,
                font=("Segoe UI", 17, "bold"),
                fg_color=bg, hover_color=hv,
                text_color=tc, corner_radius=10,
                command=cmd,
            ).grid(row=r, column=c, padx=4, pady=4)

# ─── MAINTENANCE MODE ─────────────────────────────────────────────────────────

def show_maintenance():
    grid_frame.pack_forget()
    size_frame.pack_forget()

    for w in maintenance_frame.winfo_children():
        w.destroy()

    maintenance_frame.pack(expand=True, fill="both", padx=40, pady=20)
    header_title.configure(text=t("maint_title"))

    ctk.CTkLabel(
        maintenance_frame, text=t("maint_sub"),
        font=("Segoe UI", 14),
        text_color=TEXT_SECONDARY, fg_color=BG,
    ).pack(pady=(0, 20))

    pump_dots = {}

    pumps_frame = ctk.CTkFrame(maintenance_frame, fg_color="transparent")
    pumps_frame.pack(fill="x")

    for drink_key, pump_key in DRINK_TO_PUMP.items():
        row = ctk.CTkFrame(pumps_frame, fg_color=CARD, corner_radius=12, height=70)
        row.pack(fill="x", pady=6)
        row.pack_propagate(False)

        dot = ctk.CTkLabel(
            row, text="●",
            font=("Segoe UI", 13), text_color=BORDER,
            fg_color=CARD,
        )
        dot.place(x=16, rely=0.5, anchor="w")

        ctk.CTkLabel(
            row, text=drink_name(drink_key),
            font=("Segoe UI", 15, "bold"),
            text_color=TEXT, fg_color=CARD,
        ).place(relx=0.22, rely=0.5, anchor="w")

        pump_dots[drink_key] = dot

        def make_on(dk=drink_key, pk=pump_key):
            def _():
                pumps.start_manual(pk)
                pump_dots[dk].configure(text_color=SUCCESS)
            return _

        def make_off(dk=drink_key, pk=pump_key):
            def _():
                pumps.stop(pk)
                pump_dots[dk].configure(text_color=BORDER)
            return _

        ctk.CTkButton(
            row, text=t("pump_on"),
            width=84, height=38,
            font=("Segoe UI", 13, "bold"),
            fg_color=SUCCESS, hover_color=GREEN_HOVER,
            text_color="#000000", corner_radius=8,
            command=make_on(),
        ).place(relx=0.68, rely=0.5, anchor="center")

        ctk.CTkButton(
            row, text=t("pump_off"),
            width=84, height=38,
            font=("Segoe UI", 13, "bold"),
            fg_color=CARD_HOVER, hover_color=BORDER,
            text_color=TEXT, corner_radius=8,
            border_width=1, border_color=BORDER,
            command=make_off(),
        ).place(relx=0.86, rely=0.5, anchor="center")

    def stop_all_cb():
        pumps.stop_all()
        for d in pump_dots.values():
            d.configure(text_color=BORDER)

    ctk.CTkButton(
        maintenance_frame, text=t("stop_all"),
        font=("Segoe UI", 14, "bold"),
        fg_color=ACCENT, hover_color=ACCENT_HOVER,
        text_color=TEXT, corner_radius=10, height=48,
        command=stop_all_cb,
    ).pack(fill="x", pady=(20, 8))

    ctk.CTkButton(
        maintenance_frame, text=t("exit_maint"),
        font=("Segoe UI", 13),
        fg_color="transparent", hover_color=BORDER,
        text_color=TEXT_SECONDARY,
        border_width=1, border_color=BORDER,
        corner_radius=8, height=40,
        command=show_main_view,
    ).pack(fill="x")


root.mainloop()
