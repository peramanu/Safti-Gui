"""
SAFTI – Smart Beverage Dispenser
Touchscreen UI built with tkinter.
"""

import tkinter as tk
import pumps

# ── Styling ──────────────────────────────────────────────────────────────────
BG          = "#1a1a2e"
ACCENT      = "#e94560"
BTN_BG      = "#16213e"
BTN_FG      = "#eaeaea"
BTN_ACTIVE  = "#0f3460"
FONT_TITLE  = ("Helvetica", 36, "bold")
FONT_BTN    = ("Helvetica", 22, "bold")
FONT_SMALL  = ("Helvetica", 16)

DRINKS = ["Orange", "Apple", "Multivitamin", "Water"]
VOLUMES = [0.2, 0.3, 0.5]
DRINK_ICONS = {
    "Orange":       "Orange",
    "Apple":        "Apfel",
    "Multivitamin": "Multivitamin",
    "Water":        "Wasser",
}


class SaftiApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SAFTI")
        self.configure(bg=BG)
        self.attributes("-fullscreen", True)

        # Escape zum Beenden (nützlich beim Entwickeln)
        self.bind("<Escape>", lambda e: self.destroy())

        pumps.setup()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self._show_main()

    # ── Hilfsfunktionen ───────────────────────────────────────────────────────

    def _clear(self):
        for widget in self.winfo_children():
            widget.destroy()

    def _btn(self, parent, text, command, **kwargs):
        defaults = dict(
            bg=BTN_BG, fg=BTN_FG,
            activebackground=BTN_ACTIVE, activeforeground=BTN_FG,
            font=FONT_BTN, relief="flat", bd=0,
            cursor="hand2", padx=20, pady=18,
        )
        defaults.update(kwargs)
        return tk.Button(parent, text=text, command=command, **defaults)

    # ── Hauptbildschirm: Getränkauswahl ───────────────────────────────────────

    def _show_main(self):
        self._clear()

        tk.Label(self, text="SAFTI", font=FONT_TITLE,
                 bg=BG, fg=ACCENT).pack(pady=(40, 10))
        tk.Label(self, text="Wähle dein Getränk",
                 font=FONT_SMALL, bg=BG, fg=BTN_FG).pack(pady=(0, 30))

        grid = tk.Frame(self, bg=BG)
        grid.pack(expand=True)

        for i, drink in enumerate(DRINKS):
            row, col = divmod(i, 2)
            label = DRINK_ICONS.get(drink, drink)
            btn = self._btn(
                grid,
                text=label,
                command=lambda d=drink: self._show_size(d),
                width=16,
            )
            btn.grid(row=row, column=col, padx=20, pady=15, sticky="nsew")

    # ── Mengenauswahl ─────────────────────────────────────────────────────────

    def _show_size(self, drink: str):
        self._clear()

        label = DRINK_ICONS.get(drink, drink)
        tk.Label(self, text=label, font=FONT_TITLE,
                 bg=BG, fg=ACCENT).pack(pady=(40, 10))
        tk.Label(self, text="Wähle die Menge",
                 font=FONT_SMALL, bg=BG, fg=BTN_FG).pack(pady=(0, 30))

        btn_frame = tk.Frame(self, bg=BG)
        btn_frame.pack(expand=True)

        for vol in VOLUMES:
            btn = self._btn(
                btn_frame,
                text=f"{int(vol * 1000)} ml",
                command=lambda v=vol: self._start_dispense(drink, v),
                width=12,
            )
            btn.pack(pady=12)

        self._btn(btn_frame, text="Zurueck",
                  command=self._show_main,
                  bg=BG, fg=ACCENT).pack(pady=(30, 0))

    # ── Zapfvorgang ───────────────────────────────────────────────────────────

    def _start_dispense(self, drink: str, volume: float):
        self._clear()

        label = DRINK_ICONS.get(drink, drink)
        ml = int(volume * 1000)
        duration = pumps.VOLUME_DURATIONS[volume]

        tk.Label(self, text=label, font=FONT_TITLE,
                 bg=BG, fg=ACCENT).pack(pady=(50, 10))

        status_var = tk.StringVar(value=f"Zapfe {ml} ml ...")
        tk.Label(self, textvariable=status_var,
                 font=FONT_BTN, bg=BG, fg=BTN_FG).pack(pady=20)

        # Fortschrittsbalken
        canvas = tk.Canvas(self, width=500, height=30, bg=BTN_BG,
                           highlightthickness=0)
        canvas.pack(pady=10)
        bar = canvas.create_rectangle(0, 0, 0, 30, fill=ACCENT, outline="")

        def _update_progress(elapsed: float):
            frac = min(elapsed / duration, 1.0)
            canvas.coords(bar, 0, 0, 500 * frac, 30)
            if elapsed < duration:
                self.after(100, _update_progress, elapsed + 0.1)

        def _on_done():
            # Vom Pump-Thread aufgerufen → UI-Update im Hauptthread
            self.after(0, self._show_done, drink, ml)

        pumps.dispense(drink, volume, on_finish=_on_done)
        _update_progress(0.0)

    # ── Fertig-Bildschirm ─────────────────────────────────────────────────────

    def _show_done(self, drink: str, ml: int):
        self._clear()

        label = DRINK_ICONS.get(drink, drink)
        tk.Label(self, text="Fertig!", font=FONT_TITLE,
                 bg=BG, fg=ACCENT).pack(pady=(60, 10))
        tk.Label(self, text=f"{label}  –  {ml} ml",
                 font=FONT_BTN, bg=BG, fg=BTN_FG).pack(pady=20)

        self._btn(self, text="Neues Getraenk",
                  command=self._show_main).pack(pady=40)

    # ── Aufräumen beim Beenden ────────────────────────────────────────────────

    def _on_close(self):
        pumps.cleanup()
        self.destroy()


if __name__ == "__main__":
    app = SaftiApp()
    app.mainloop()
